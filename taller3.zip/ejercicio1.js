/*1. Cree un conjunto de objetos literales donde el usuario ingrese los datos de
cada objeto, al final los debe almacenar en un array e imprimir por consola
todos los objetos creados.*/



const objetos = [];

let limite = prompt('ingrese cuantos objetos va crear: ');
const crear_objeto = (nombre, edad) => ({nombre, edad});

for (let i = 0; i < limite; i++){
    let nombre = prompt('ingrese el nombre: ');
    let edad = prompt ('ingrese la edad: ');
    
    objetos.push(crear_objeto(nombre,edad));
}

console.log(objetos);