function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min; 
}

let cantidad = parseInt(prompt("Ingrese la cantidad de numeros que iran en el arreglo: "));
let arreglo_num = [];

for (let j = 0; j < cantidad; j++) { 
    let numero = getRandomInt(1, 100);
    arreglo_num.push(numero);
}
console.log(arreglo_num)

for (let i = 0; i < arreglo_num.length; i++) {
    if (arreglo_num[i] % 2 === 0) { 
        arreglo_num[i] = 'par';
    }
}
console.log(arreglo_num);