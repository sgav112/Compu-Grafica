/*3. Cree un algoritmo que le pida al usuario números de mas de dos cifras, los
guarde en un arreglo, al final me debe imprimir todos los números
ingresados y debe decir la cantidad de cifras que tiene.*/




const numeros = [];

let limite = prompt('ingrese cuantos objetos va crear: ');


for (let i = 0; i < limite; i++){
    let numero = parseInt(prompt(`Ingrese el número ${i + 1} de dos cifras : `));
    if(numero >= 10){
        numeros.push(numero);
    }else{
        prompt('numero no permitido')
    }
    
}



console.log(numeros);

// Calcular y mostrar la cantidad de cifras de cada número
for (let i = 0; i < numeros.length; i++) {
    const cifras = numeros[i].toString().length;
    console.log(`El número ${numeros[i]} tiene ${cifras} cifras.`);
}
