function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

let arreglo_numeros = []
for(let i = 0;i < 101; i++){
    let numero = getRandomInt(1, 100)
    arreglo_numeros.push(numero)
}
console.log (arreglo_numeros)
let cuarta_parte = Math.ceil(arreglo_numeros.length / 4);
let final = 0
let arreglo_final = []
for (let j = 0; j < cuarta_parte; j++) {
    final = arreglo_numeros[j]
    arreglo_final.push(final)
}

console.log(arreglo_final)