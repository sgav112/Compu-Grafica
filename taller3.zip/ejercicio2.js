/*2. Implemente un método o función para modificar, añadir o eliminar atributos
de los objetos creados en el punto 1.*/

const objetos = [];

let limite = prompt('ingrese cuantos objetos va crear: ');
const crear_objeto = (nombre, edad) => ({ nombre, edad });

for (let i = 0; i < limite; i++) {
    let nombre = prompt('ingrese el nombre: ');
    let edad = prompt('ingrese la edad: ');

    objetos.push(crear_objeto(nombre, edad));
}


function menu() {
    return prompt('menu \n1)añadir atributos  de los objetos \n2)modificar atributos de los objetos\n3)eliminar atributos de los objetos \n4)salir')
}

function añadir() {
    let nombre = prompt('ingrese el nombre: ');
    let edad = prompt('ingrese la edad: ');
    objetos.push(crear_objeto(nombre, edad))
}

function eliminar() {
    let dato = parseInt(prompt('ingrese el objeto que quiere eliminar '))
    if (dato >= 0 && dato < objetos.length) {
        objetos.splice(dato, 1);
    } else {
        console.log('Índice fuera de rango.');
    }
}

function modificar() {
    let dato = parseInt(prompt('Ingrese el índice del objeto que desea modificar: '));
    if (dato >= 0 && dato < objetos.length) {
        let atributo = prompt('Ingrese el nombre del atributo que desea modificar (nombre o edad): ');

        if (atributo === 'nombre' || atributo === 'edad') {
            let nuevoValor = prompt(`Ingrese el nuevo valor para ${atributo}: `);
            objetos[dato][atributo] = nuevoValor;
            console.log(`${atributo} modificado exitosamente.`);
        } else {
            console.log('El objeto no tiene el atributo especificado.');
        }
    } else {
        console.log('Índice fuera de rango.');
    }
}



let opcion = 0;
do {
    opcion = parseInt(menu())
    switch (opcion) {
        case 1:
            añadir()
            break

        case 2:
            modificar()
            break

        case 3:
            eliminar()
            break
    }


} while (opcion !== 4)

console.log(objetos);
