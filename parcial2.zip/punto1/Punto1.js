let canvas = document.getElementById('lienzo');
let ctx = canvas.getContext('2d');



function trazo(x, y, xfin, yfin, color) {
    ctx.beginPath();
    ctx.strokeStyle = color; 
    ctx.moveTo(x, y);
    ctx.lineTo(xfin, yfin);
    ctx.stroke();
    ctx.closePath();
}

trazo(40, 250, 360, 350, 'red');
trazo(360, 350, 220, 60, 'red');
trazo(40, 250, 220, 60, 'red');
trazo(134,150 ,287 ,200 , 'red');
trazo(134,150 ,190 ,296 , 'red');
trazo(190 ,296 ,287 ,200 , 'red');
trazo(370, 340, 230, 50, 'red');
trazo(360, 350, 370, 340, 'red');
trazo(220, 60, 230, 50, 'red');
trazo(282, 205, 298 ,190, 'red');







